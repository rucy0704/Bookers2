# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '55ad35d6c88342ac169e6060c9ce0f8d5b081a0688c3c8f3ec9d7867647cf1f77fd9da92e058b84cd841ba901303e83decce11b310d9b76a9ff2b7e259de02f6'